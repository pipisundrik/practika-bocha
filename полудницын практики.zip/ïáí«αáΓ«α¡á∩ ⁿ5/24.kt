//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    //это 25 задание
    println("Кубы чисел от 1 до 10:")
    for (i in 1..10) {
        println("${i}³ = ${i * i * i}")
    }
}