//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    println("Введите строку:")
    val a = readLine()!!

    val d = a.reversed()
    println("Строка в обратном порядке: $d")
}