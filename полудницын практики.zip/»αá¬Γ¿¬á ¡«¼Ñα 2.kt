fun main() {
    // Операции с числами

    // Задание 1. Дано двузначное число.
    val twoDigitNumber = 34 // Пример двузначного числа
    val tens = twoDigitNumber / 10 // Число десятков
    val units = twoDigitNumber % 10 // Число единиц
    val sumOfDigits = tens + units // Сумма цифр
    val productOfDigits = tens * units // Произведение цифр

    println("Задание 1:")
    println("а) Число десятков: $tens")
    println("б) Число единиц: $units")
    println("в) Сумма цифр: $sumOfDigits")
    println("г) Произведение цифр: $productOfDigits")

    // Задание 2. Дано трехзначное число.
    val threeDigitNumber = 123 // Пример трехзначного числа
    val hundreds = threeDigitNumber / 100
    val tensThreeDigit = (threeDigitNumber % 100) / 10
    val unitsThreeDigit = threeDigitNumber % 10
    val sumOfDigitsThreeDigit = hundreds + tensThreeDigit + unitsThreeDigit
    val productOfDigitsThreeDigit = hundreds * tensThreeDigit * unitsThreeDigit

    println("\\nЗадание 2:")
    println("а) Число единиц: $unitsThreeDigit")
    println("б) Число десятков: $tensThreeDigit")
    println("в) Сумма цифр: $sumOfDigitsThreeDigit")
    println("г) Произведение цифр: $productOfDigitsThreeDigit")

    // Задание 3. Программа, которая делит одно число на другое.
    val numerator = 20
    val denominator = 4
    val divisionResult = numerator / denominator

    println("\\nЗадание 3:")
    println("Результат деления $numerator на $denominator: $divisionResult")

    // Задание 4. Программа, которая возведет число в определенную степень.
    val base = 2
    val exponent = 3
    val powerResult = Math.pow(base.toDouble(), exponent.toDouble())

    println("\\nЗадание 4:")
    println("$base в степени $exponent: $powerResult")

    // Задание 5. Программа, которая найдёт корень числа.
    val numberForRoot = 16
    val squareRoot = Math.sqrt(numberForRoot.toDouble())

    println("\\nЗадание 5:")
    println("Корень числа $numberForRoot: $squareRoot")

    // Вычисление логических выражений

    // Задание 1
    val A = true
    val B = false
    val C = false
    println("\\nЗадание 1:")
    println("а) A или B: ${A || B}")
    println("б) A и B: ${A && B}")
    println("в) B или C: ${B || C}")

    // Задание 2
    val X = false
    val Y = true
    val Z = false
    println("\\nЗадание 2:")
    println("а) X или Z: ${X || Z}")
    println("б) X и Y: ${X && Y}")
    println("в) X и Z: ${X && Z}")

    // Задание 3
    println("\\nЗадание 3:")
    println("а) не A и B: ${!A && B}")
    println("б) A или не B: ${A || !B}")
    println("в) A и B или C: ${(A && B) || C}")

    // Задание 4
    println("\\nЗадание 4:")
    println("а) не X и Y: ${!X && Y}")
    println("б) X или не Y: ${X || !Y}")
    println("в) X или Y и Z: ${X || (Y && Z)}")

    // Задание 5
    println("\\nЗадание 5:")
    println("а) не X и Y: ${!X && Y}")
    println("б) X или не Y: ${X || !Y}")
    println("в) X или Y и Z: ${X || (Y && Z)}")

    // Задание 6
    val newX = false
    val newY = false
    val newZ = true
    println("\\nЗадание 6:")
    println("а) X или Y и не Z: ${newX || (newY && !newZ)}")
    println("б) X и не Y или Z: ${newX && !newY || newZ}")
    println("в) не X и не Y: ${!newX && !newY}")
    println("г) X и (не Y или Z): ${newX && (!newY || newZ)}")
    println("д) не (X и Z) или Y: {!newX && newZ || newY}")
    println("е) X или (не (Y или Z)): ${newX || !(newY || newZ)}")

    // Задание 7
    println("\\nЗадание 7:")
    println("а) A или не (A и B) или C: ${A || !(A && B) || C}")
    println("б) не A или A и (B или C): {!A || (A && (B || C))}")
    println("в) (A или B и не C) и C: {(A || (B && !C)) && C}")
}